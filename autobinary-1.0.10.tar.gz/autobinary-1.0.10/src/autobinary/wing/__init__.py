from autobinary.wing.main import WingOfEvidence, WingsOfEvidence
