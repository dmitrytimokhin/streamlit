__all__ = ["__title__", "__uri__", "__version__"]

__title__ = "ITMO_FS"
__uri__ = "https://github.com/ctlab/ITMO_FS"

__version__ = "0.3.4"
