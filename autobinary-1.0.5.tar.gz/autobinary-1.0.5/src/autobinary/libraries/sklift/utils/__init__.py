from .utils import check_is_binary

__all__ = ['check_is_binary']